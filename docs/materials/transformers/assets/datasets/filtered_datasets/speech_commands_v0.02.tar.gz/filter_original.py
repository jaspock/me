import os
import random

def reduce(directory, num_files=110):
    """ Reduces the number of files in the specified directory to 220 by randomly deleting excess files. """
    files = [file for file in os.listdir(directory) if os.path.isfile(os.path.join(directory, file))]
    if len(files) > num_files:
        files_to_delete = random.sample(files, len(files) - num_files)
        for file in files_to_delete:
            os.remove(os.path.join(directory, file))

def process_directories(root_directory, num_files=110, train=100, validation=5, test=5):
    """ Processes each subdirectory in the root directory to create train, validation, and test datasets. """
    assert train + validation + test == num_files, "Total sum must be equal to num_files"

    # Initialize lists to store file paths
    train_files = []
    validation_files = []
    test_files = []

    # Process each subdirectory
    for subdir in os.listdir(root_directory):
        subdir_path = os.path.join(root_directory, subdir)
        if os.path.isdir(subdir_path):
            # Reduce to 220 files
            reduce(subdir_path, num_files)

            # List all files in the subdirectory
            files = [file for file in os.listdir(subdir_path) if os.path.isfile(os.path.join(subdir_path, file))]
            
            # Randomly select files
            selected_files = random.sample(files, num_files)
            
            # Divide into train, validation, and test
            train_files.extend([os.path.join(subdir, file) for file in selected_files[:train]])
            validation_files.extend([os.path.join(subdir, file) for file in selected_files[train:train + validation]])
            test_files.extend([os.path.join(subdir, file) for file in selected_files[train + validation:]])

    # Write to text files
    with open('training_list.txt', 'w') as f:
        for item in train_files:
            f.write("%s\n" % item)
    with open('validation_list.txt', 'w') as f:
        for item in validation_files:
            f.write("%s\n" % item)
    with open('testing_list.txt', 'w') as f:
        for item in test_files:
            f.write("%s\n" % item)

# Use the function on your root directory
process_directories('.')
