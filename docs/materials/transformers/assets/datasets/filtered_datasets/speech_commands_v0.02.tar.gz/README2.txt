This is a version of the dataset filtered to have only 110 files per directory. The aim 
of this is to have a much smaller corpus for educational purposes that can be downloaded 
much faster.
